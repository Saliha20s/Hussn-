
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
import joblib

# بيانات تدريبية بسيطة (للتوضيح فقط)
urls = [
    "free porn videos", "xxx movies", "adult content",  # مواقع غير لائقة
    "educational website", "news articles", "science blog"  # مواقع آمنة
]

labels = [1, 1, 1, 0, 0, 0]  # 1 = غير لائق، 0 = آمن

# تحويل النصوص إلى أرقام
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(urls)

# تدريب نموذج تصنيف
model = LogisticRegression()
model.fit(X, labels)

# حفظ النموذج والمتجه
joblib.dump(model, 'model.pkl')
joblib.dump(vectorizer, 'vectorizer.pkl')
