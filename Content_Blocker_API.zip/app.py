
from flask import Flask, request, jsonify
import joblib
import re

app = Flask(__name__)

# تحميل النموذج المدرب
model = joblib.load('model.pkl')
vectorizer = joblib.load('vectorizer.pkl')

# دالة لمعالجة الرابط أو النص
def clean_text(text):
    text = re.sub(r"http\S+|www\S+|https\S+", '', text, flags=re.MULTILINE)
    text = re.sub(r'\W', ' ', text)
    text = text.lower()
    return text

# نقطة النهاية للتحقق من الرابط
@app.route('/check_url', methods=['POST'])
def check_url():
    data = request.get_json()
    url = data.get('url', '')

    if not url:
        return jsonify({'error': 'No URL provided'}), 400

    cleaned_url = clean_text(url)
    vectorized_url = vectorizer.transform([cleaned_url])
    prediction = model.predict(vectorized_url)

    if prediction[0] == 1:
        return jsonify({'result': 'Blocked', 'message': 'This site is blocked due to inappropriate content.'})
    else:
        return jsonify({'result': 'Allowed', 'message': 'This site is safe to visit.'})

if __name__ == '__main__':
    app.run(debug=True)
